module DesafioQuadros {
	exports desafioeDosQuadros;

	requires java.desktop;
	requires java.logging;
}